﻿DragonWarriorEquipmentAndMagicDataEditor 1.0.0.28694
Coded by: Shawn M. Crawford [sleepy9090]
February 8, 2018

-Requires .NET Framework 3.5

DragonWarriorEquipmentAndMagicDataEditor 
Program to edit weapon and armor stats and magic data in the NES game Dragon Warrior. 

-Tested with headered Dragon Warrior (U) (PRG0) [!].nes ROM.
-Tested with headered Dragon Warrior (U) (PRG1) [!].nes ROM.

Feel free to send bugs to sleepy3d@email.com or file them on github: https://github.com/sleepy9090

Version: 1.0.0.28694 February 8, 2018
-first version


